java -Dapplication.defaultlaf=system -cp ../SX.jar CommentReadSample
java -Dapplication.defaultlaf=system -cp ../SX.jar CommentWriteSample