java -Dapplication.defaultlaf=system -cp ../SX.jar RangeStyleSample
java -Dapplication.defaultlaf=system -cp ../SX.jar TextFormattingSample