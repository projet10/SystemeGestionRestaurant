java -Dapplication.defaultlaf=system -cp ../SX.jar WriteImagesSample
java -Dapplication.defaultlaf=system -cp ../SX.jar ReadImageSample