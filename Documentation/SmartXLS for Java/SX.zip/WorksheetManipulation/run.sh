java -Dapplication.defaultlaf=system -cp ../SX.jar FreezepaneSample
java -Dapplication.defaultlaf=system -cp ../SX.jar HideUnhideRowsandColumnsSample
java -Dapplication.defaultlaf=system -cp ../SX.jar MultiSheetTestSample
java -Dapplication.defaultlaf=system -cp ../SX.jar PageBreakSample
java -Dapplication.defaultlaf=system -cp ../SX.jar RowHeightandColumnWidthSample